create view avaliacoes_usuarios (nome_avaliador, nome_avaliado, mensagem_da_avaliacao, nota_da_avaliacao) as
SELECT u1.nome     AS nome_avaliador,
       u2.nome     AS nome_avaliado,
       av.mensagem AS mensagem_da_avaliacao,
       av.nota     AS nota_da_avaliacao
FROM avalia a
         JOIN usuarios u1 ON a.avaliadorid = u1.id
         JOIN usuarios u2 ON a.avaliadoid = u2.id
         JOIN avaliacoes av ON a.avaliacaoid = av.id
ORDER BY u1.dataregistro DESC;

alter table avaliacoes_usuarios
    owner to postgres;

